<?php
	$metas = array(
		"farol" => array(
			"title" => "¿quién eres en las retas?",
			"description" => "A ti lo que te importa es verte bien",
			"image" => "images/metas/0.png" 
		),
		"capitan" => array(
			"title" => "¿quién eres en las retas?",
			"description" => "Eres el capitán de tu equipo",
			"image" => "images/metas/1.png" 
		)
		,
		"crack" => array(
			"title" => "¿quién eres en las retas?",
			"description" => "Eres el mago del equipo",
			"image" => "images/metas/2.png" 
		)
		,
		"tronco" => array(
			"title" => "¿quién eres en las retas?",
			"description" => "La verdad estás en el equipo por ser buena onda",
			"image" => "images/metas/3.png" 
		)
	);